from pymatting.foreground.estimate_foreground_cf import estimate_foreground_cf
from pymatting.foreground.estimate_foreground_ml import estimate_foreground_ml
from pymatting.foreground.estimate_foreground_ml import (
    estimate_foreground_ml as estimate_foreground,
)
